import { Router } from "express";
import { storage } from "./storage";
import { z } from "zod";

// Simple validation schemas for frontend-only version
const restaurantFormSchema = z.object({
  name: z.string().min(1, "Restaurant name is required"),
  address: z.string().min(1, "Address is required"),
  phone: z.string().min(1, "Phone is required"),
  email: z.string().email("Valid email is required"),
  cuisine: z.string().min(1, "Cuisine is required"),
  status: z.enum(["active", "inactive", "pending"]).default("active"),
  rating: z.string().default("4.5")
});

const orderFormSchema = z.object({
  customerId: z.number(),
  restaurantId: z.number(),
  status: z.enum(["pending", "confirmed", "preparing", "ready", "delivered", "cancelled"]).default("pending"),
  items: z.array(z.object({
    name: z.string(),
    quantity: z.number(),
    price: z.number()
  })),
  total: z.string().min(1, "Total is required"),
  deliveryAddress: z.string().min(1, "Delivery address is required"),
  paymentStatus: z.enum(["pending", "paid", "failed"]).default("pending"),
  notes: z.string().optional()
});

const customerSchema = z.object({
  name: z.string().min(1, "Customer name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().min(1, "Phone is required"),
  address: z.string().min(1, "Address is required")
});

const notificationSchema = z.object({
  title: z.string().min(1, "Title is required"),
  message: z.string().min(1, "Message is required"),
  type: z.string().min(1, "Type is required"),
  relatedId: z.number().optional(),
  isRead: z.boolean().default(false)
});

const router = Router();

// Restaurants routes
router.get("/restaurants", async (req, res) => {
  try {
    const restaurants = await storage.getRestaurants();
    res.json(restaurants);
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    res.status(500).json({ error: "Failed to fetch restaurants" });
  }
});

router.get("/restaurants/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const restaurant = await storage.getRestaurant(id);
    if (!restaurant) {
      return res.status(404).json({ error: "Restaurant not found" });
    }
    res.json(restaurant);
  } catch (error) {
    console.error("Error fetching restaurant:", error);
    res.status(500).json({ error: "Failed to fetch restaurant" });
  }
});

router.post("/restaurants", async (req, res) => {
  try {
    const data = restaurantFormSchema.parse(req.body);
    const restaurant = await storage.createRestaurant(data);
    
    // Create notification
    await storage.createNotification({
      type: "restaurant",
      title: "New Restaurant Added",
      message: `${restaurant.name} has been added to the platform`,
      relatedId: restaurant.id
    });
    
    res.json(restaurant);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: error.errors });
    }
    console.error("Error creating restaurant:", error);
    res.status(500).json({ error: "Failed to create restaurant" });
  }
});

router.put("/restaurants/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const data = restaurantFormSchema.partial().parse(req.body);
    const restaurant = await storage.updateRestaurant(id, data);
    res.json(restaurant);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: error.errors });
    }
    console.error("Error updating restaurant:", error);
    res.status(500).json({ error: "Failed to update restaurant" });
  }
});

router.delete("/restaurants/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await storage.deleteRestaurant(id);
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting restaurant:", error);
    res.status(500).json({ error: "Failed to delete restaurant" });
  }
});

// Customers routes
router.get("/customers", async (req, res) => {
  try {
    const customers = await storage.getCustomers();
    res.json(customers);
  } catch (error) {
    console.error("Error fetching customers:", error);
    res.status(500).json({ error: "Failed to fetch customers" });
  }
});

router.get("/customers/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const customer = await storage.getCustomer(id);
    if (!customer) {
      return res.status(404).json({ error: "Customer not found" });
    }
    res.json(customer);
  } catch (error) {
    console.error("Error fetching customer:", error);
    res.status(500).json({ error: "Failed to fetch customer" });
  }
});

router.post("/customers", async (req, res) => {
  try {
    const data = customerSchema.parse(req.body);
    const customer = await storage.createCustomer(data);
    res.json(customer);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: error.errors });
    }
    console.error("Error creating customer:", error);
    res.status(500).json({ error: "Failed to create customer" });
  }
});

// Orders routes
router.get("/orders", async (req, res) => {
  try {
    const orders = await storage.getOrders();
    res.json(orders);
  } catch (error) {
    console.error("Error fetching orders:", error);
    res.status(500).json({ error: "Failed to fetch orders" });
  }
});

router.get("/orders/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const order = await storage.getOrder(id);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    res.json(order);
  } catch (error) {
    console.error("Error fetching order:", error);
    res.status(500).json({ error: "Failed to fetch order" });
  }
});

router.post("/orders", async (req, res) => {
  try {
    const data = orderFormSchema.parse(req.body);
    const order = await storage.createOrder({
      ...data,
      total: data.total // Convert string to decimal format
    });
    
    // Create notification for new order
    await storage.createNotification({
      type: "order",
      title: "New Order Received",
      message: `Order #${order.id} placed for $${order.total}`,
      relatedId: order.id
    });
    
    res.json(order);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: error.errors });
    }
    console.error("Error creating order:", error);
    res.status(500).json({ error: "Failed to create order" });
  }
});

router.put("/orders/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const data = orderFormSchema.partial().parse(req.body);
    const order = await storage.updateOrder(id, data);
    
    // Create notification for status change if status was updated
    if (data.status) {
      await storage.createNotification({
        type: "order",
        title: "Order Status Updated",
        message: `Order #${order.id} status changed to ${data.status}`,
        relatedId: order.id
      });
    }
    
    res.json(order);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: error.errors });
    }
    console.error("Error updating order:", error);
    res.status(500).json({ error: "Failed to update order" });
  }
});

// Notifications routes
router.get("/notifications", async (req, res) => {
  try {
    const notifications = await storage.getNotifications();
    res.json(notifications);
  } catch (error) {
    console.error("Error fetching notifications:", error);
    res.status(500).json({ error: "Failed to fetch notifications" });
  }
});

router.get("/notifications/unread", async (req, res) => {
  try {
    const notifications = await storage.getUnreadNotifications();
    res.json(notifications);
  } catch (error) {
    console.error("Error fetching unread notifications:", error);
    res.status(500).json({ error: "Failed to fetch unread notifications" });
  }
});

router.put("/notifications/:id/read", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await storage.markNotificationAsRead(id);
    res.json({ success: true });
  } catch (error) {
    console.error("Error marking notification as read:", error);
    res.status(500).json({ error: "Failed to mark notification as read" });
  }
});

router.post("/notifications", async (req, res) => {
  try {
    const data = notificationSchema.parse(req.body);
    const notification = await storage.createNotification(data);
    res.json(notification);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Validation failed", details: error.errors });
    }
    console.error("Error creating notification:", error);
    res.status(500).json({ error: "Failed to create notification" });
  }
});

// Analytics routes
router.get("/analytics/dashboard", async (req, res) => {
  try {
    const stats = await storage.getDashboardStats();
    res.json(stats);
  } catch (error) {
    console.error("Error fetching dashboard analytics:", error);
    res.status(500).json({ error: "Failed to fetch dashboard analytics" });
  }
});

router.get("/analytics/restaurants/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const analytics = await storage.getRestaurantAnalytics(id);
    res.json(analytics);
  } catch (error) {
    console.error("Error fetching restaurant analytics:", error);
    res.status(500).json({ error: "Failed to fetch restaurant analytics" });
  }
});

// Test data creation endpoint
router.post("/test/create-sample-data", async (req, res) => {
  try {
    // Create sample restaurants
    const restaurant1 = await storage.createRestaurant({
      name: "Mario's Italian Kitchen",
      address: "123 Main St, Downtown",
      phone: "+1-555-0123",
      email: "info@marios.com",
      cuisine: "Italian",
      status: "active"
    });

    const restaurant2 = await storage.createRestaurant({
      name: "Sushi Zen",
      address: "456 Oak Ave, Uptown",
      phone: "+1-555-0124",
      email: "orders@sushizen.com",
      cuisine: "Japanese",
      status: "active"
    });

    // Create sample customers
    const customer1 = await storage.createCustomer({
      name: "John Smith",
      email: "john.smith@email.com",
      phone: "+1-555-0100",
      address: "789 Pine St, Residential Area"
    });

    const customer2 = await storage.createCustomer({
      name: "Sarah Johnson",
      email: "sarah.j@email.com",
      phone: "+1-555-0101",
      address: "321 Elm St, Suburbs"
    });

    // Create sample orders
    await storage.createOrder({
      customerId: customer1.id,
      restaurantId: restaurant1.id,
      status: "delivered",
      items: [
        { name: "Margherita Pizza", quantity: 1, price: 18.99 },
        { name: "Caesar Salad", quantity: 1, price: 12.99 }
      ],
      total: "31.98",
      deliveryAddress: customer1.address,
      paymentStatus: "paid"
    });

    await storage.createOrder({
      customerId: customer2.id,
      restaurantId: restaurant2.id,
      status: "preparing",
      items: [
        { name: "Salmon Roll", quantity: 2, price: 8.99 },
        { name: "Miso Soup", quantity: 1, price: 4.99 }
      ],
      total: "22.97",
      deliveryAddress: customer2.address,
      paymentStatus: "paid"
    });

    // Create sample notifications
    await storage.createNotification({
      type: "system",
      title: "System Initialized",
      message: "Welcome to Snapmenu Admin Panel! Sample data has been created.",
      relatedId: null
    });

    res.json({ 
      success: true, 
      message: "Sample data created successfully",
      data: {
        restaurants: 2,
        customers: 2,
        orders: 2,
        notifications: 1
      }
    });
  } catch (error) {
    console.error("Error creating sample data:", error);
    res.status(500).json({ error: "Failed to create sample data" });
  }
});

export default router;
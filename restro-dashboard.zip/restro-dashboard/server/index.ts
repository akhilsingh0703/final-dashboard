import express from "express";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import path from "path";
import { fileURLToPath } from "url";
import routes from "./routes";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });

const port = parseInt(process.env.PORT || "5000", 10);
const isDev = process.env.NODE_ENV === "development";

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API routes
app.use("/api", routes);

// WebSocket for real-time notifications
wss.on("connection", (ws) => {
  console.log("Client connected to WebSocket");
  
  ws.on("close", () => {
    console.log("Client disconnected from WebSocket");
  });
});

if (isDev) {
  // Development mode - serve pre-built frontend
  console.log("Setting up development file serving...");
  
  // Check if dist/public exists (built frontend)
  const distPath = path.resolve(process.cwd(), "dist/public");
  const clientPath = path.resolve(process.cwd(), "client");
  
  try {
    await import("fs").then(fs => fs.promises.access(distPath));
    // Serve built files if they exist
    app.use(express.static(distPath));
    console.log("Serving built frontend from dist/public");
  } catch {
    // Fallback to client directory
    app.use(express.static(clientPath));
    console.log("Serving client files directly");
  }
  
  // SPA fallback - serve index.html for all non-API routes
  app.get("*", (req, res) => {
    if (req.path.startsWith('/api/')) {
      return; // Let API routes handle themselves
    }
    
    try {
      res.sendFile(path.resolve(distPath, "index.html"));
    } catch {
      res.sendFile(path.resolve(clientPath, "index.html"));
    }
  });
} else {
  // Production mode - serve static files
  const staticPath = path.resolve(__dirname, "../dist/public");
  app.use(express.static(staticPath));
  
  app.get("*", (req, res) => {
    res.sendFile(path.resolve(staticPath, "index.html"));
  });
}

server.listen(port, "0.0.0.0", () => {
  console.log(`Server running on http://0.0.0.0:${port}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
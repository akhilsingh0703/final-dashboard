// Simple in-memory types for frontend-only version
export type Restaurant = {
  id: number;
  name: string;
  address: string;
  phone: string;
  email: string;
  cuisine: string;
  status: string;
  rating: string;
  totalOrders: number;
  revenue: string;
  createdAt: string;
};

export type Customer = {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
  totalOrders: number;
  totalSpent: string;
  createdAt: string;
};

export type Order = {
  id: number;
  customerId: number;
  restaurantId: number;
  status: string;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
  total: string;
  deliveryAddress: string;
  paymentStatus: string;
  orderDate: string;
  deliveredAt?: string;
  notes?: string;
};

export type Notification = {
  id: number;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  relatedId?: number;
  createdAt: string;
};

export type User = {
  id: number;
  username: string;
  password: string;
  createdAt: string;
};

export type InsertRestaurant = Omit<Restaurant, 'id' | 'createdAt' | 'totalOrders' | 'revenue'>;
export type InsertCustomer = Omit<Customer, 'id' | 'createdAt' | 'totalOrders' | 'totalSpent'>;
export type InsertOrder = Omit<Order, 'id' | 'orderDate' | 'deliveredAt'>;
export type InsertNotification = Omit<Notification, 'id' | 'createdAt'>;
export type InsertUser = Omit<User, 'id' | 'createdAt'>;

export interface IStorage {
  // Users
  createUser(user: InsertUser): Promise<User>;
  getUserByUsername(username: string): Promise<User | null>;
  
  // Restaurants
  getRestaurants(): Promise<Restaurant[]>;
  getRestaurant(id: number): Promise<Restaurant | null>;
  createRestaurant(restaurant: InsertRestaurant): Promise<Restaurant>;
  updateRestaurant(id: number, restaurant: Partial<InsertRestaurant>): Promise<Restaurant>;
  deleteRestaurant(id: number): Promise<void>;
  
  // Customers
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | null>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer>;
  
  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | null>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order>;
  getOrdersByRestaurant(restaurantId: number): Promise<Order[]>;
  getOrdersByCustomer(customerId: number): Promise<Order[]>;
  
  // Notifications
  getNotifications(): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<void>;
  getUnreadNotifications(): Promise<Notification[]>;
  
  // Analytics
  getRestaurantAnalytics(restaurantId: number): Promise<{
    totalOrders: number;
    totalRevenue: number;
    averageOrderValue: number;
    recentOrders: Order[];
  }>;
  getDashboardStats(): Promise<{
    totalRestaurants: number;
    totalOrders: number;
    totalRevenue: number;
    totalCustomers: number;
    recentOrders: Order[];
  }>;
}

export class MemoryStorage implements IStorage {
  private restaurants: Restaurant[] = [];
  private customers: Customer[] = [];
  private orders: Order[] = [];
  private notifications: Notification[] = [];
  private users: User[] = [];
  private nextId = 1;

  async createUser(user: InsertUser): Promise<User> {
    const newUser: User = {
      ...user,
      id: this.nextId++,
      createdAt: new Date().toISOString()
    };
    this.users.push(newUser);
    return newUser;
  }

  async getUserByUsername(username: string): Promise<User | null> {
    return this.users.find(u => u.username === username) || null;
  }

  async getRestaurants(): Promise<Restaurant[]> {
    return [...this.restaurants].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getRestaurant(id: number): Promise<Restaurant | null> {
    return this.restaurants.find(r => r.id === id) || null;
  }

  async createRestaurant(restaurant: InsertRestaurant): Promise<Restaurant> {
    const newRestaurant: Restaurant = {
      ...restaurant,
      id: this.nextId++,
      totalOrders: 0,
      revenue: "0.00",
      createdAt: new Date().toISOString()
    };
    this.restaurants.push(newRestaurant);
    return newRestaurant;
  }

  async updateRestaurant(id: number, restaurant: Partial<InsertRestaurant>): Promise<Restaurant> {
    const index = this.restaurants.findIndex(r => r.id === id);
    if (index === -1) throw new Error("Restaurant not found");
    this.restaurants[index] = { ...this.restaurants[index], ...restaurant };
    return this.restaurants[index];
  }

  async deleteRestaurant(id: number): Promise<void> {
    this.restaurants = this.restaurants.filter(r => r.id !== id);
  }

  async getCustomers(): Promise<Customer[]> {
    return [...this.customers].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getCustomer(id: number): Promise<Customer | null> {
    return this.customers.find(c => c.id === id) || null;
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const newCustomer: Customer = {
      ...customer,
      id: this.nextId++,
      totalOrders: 0,
      totalSpent: "0.00",
      createdAt: new Date().toISOString()
    };
    this.customers.push(newCustomer);
    return newCustomer;
  }

  async updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer> {
    const index = this.customers.findIndex(c => c.id === id);
    if (index === -1) throw new Error("Customer not found");
    this.customers[index] = { ...this.customers[index], ...customer };
    return this.customers[index];
  }

  async getOrders(): Promise<Order[]> {
    return [...this.orders].sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
  }

  async getOrder(id: number): Promise<Order | null> {
    return this.orders.find(o => o.id === id) || null;
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const newOrder: Order = {
      ...order,
      id: this.nextId++,
      orderDate: new Date().toISOString()
    };
    this.orders.push(newOrder);
    
    // Update customer and restaurant statistics
    await this.updateCustomerStats(newOrder.customerId, Number(newOrder.total));
    await this.updateRestaurantStats(newOrder.restaurantId, Number(newOrder.total));
    
    return newOrder;
  }

  async updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order> {
    const index = this.orders.findIndex(o => o.id === id);
    if (index === -1) throw new Error("Order not found");
    this.orders[index] = { ...this.orders[index], ...order };
    return this.orders[index];
  }

  async getOrdersByRestaurant(restaurantId: number): Promise<Order[]> {
    return this.orders
      .filter(o => o.restaurantId === restaurantId)
      .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
  }

  async getOrdersByCustomer(customerId: number): Promise<Order[]> {
    return this.orders
      .filter(o => o.customerId === customerId)
      .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
  }

  async getNotifications(): Promise<Notification[]> {
    return [...this.notifications].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const newNotification: Notification = {
      ...notification,
      id: this.nextId++,
      createdAt: new Date().toISOString()
    };
    this.notifications.push(newNotification);
    return newNotification;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    const notification = this.notifications.find(n => n.id === id);
    if (notification) {
      notification.isRead = true;
    }
  }

  async getUnreadNotifications(): Promise<Notification[]> {
    return this.notifications
      .filter(n => !n.isRead)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getRestaurantAnalytics(restaurantId: number): Promise<{
    totalOrders: number;
    totalRevenue: number;
    averageOrderValue: number;
    recentOrders: Order[];
  }> {
    const restaurant = await this.getRestaurant(restaurantId);
    const recentOrders = await this.getOrdersByRestaurant(restaurantId);
    
    const totalOrders = restaurant?.totalOrders || 0;
    const totalRevenue = Number(restaurant?.revenue || 0);
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    return {
      totalOrders,
      totalRevenue,
      averageOrderValue,
      recentOrders: recentOrders.slice(0, 10)
    };
  }

  async getDashboardStats(): Promise<{
    totalRestaurants: number;
    totalOrders: number;
    totalRevenue: number;
    totalCustomers: number;
    recentOrders: Order[];
  }> {
    const totalRevenue = this.orders.reduce((sum, order) => sum + Number(order.total), 0);
    const recentOrders = [...this.orders]
      .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime())
      .slice(0, 5);

    return {
      totalRestaurants: this.restaurants.length,
      totalCustomers: this.customers.length,
      totalOrders: this.orders.length,
      totalRevenue,
      recentOrders
    };
  }

  private async updateCustomerStats(customerId: number, orderAmount: number): Promise<void> {
    const customer = this.customers.find(c => c.id === customerId);
    if (customer) {
      customer.totalOrders += 1;
      customer.totalSpent = (Number(customer.totalSpent) + orderAmount).toFixed(2);
    }
  }

  private async updateRestaurantStats(restaurantId: number, orderAmount: number): Promise<void> {
    const restaurant = this.restaurants.find(r => r.id === restaurantId);
    if (restaurant) {
      restaurant.totalOrders += 1;
      restaurant.revenue = (Number(restaurant.revenue) + orderAmount).toFixed(2);
    }
  }
}

export const storage = new MemoryStorage();
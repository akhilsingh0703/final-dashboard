# Installation Guide - Snapmenu Admin Panel

## Quick Setup

1. **Extract the zip file**
   ```bash
   unzip snapmenu-admin-panel.zip
   cd snapmenu-admin-panel
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   Navigate to `http://localhost:5000`

5. **Create sample data**
   Click "Create Sample Data" button in the dashboard to populate test restaurants, customers, and orders.

## Features Included

✅ **Restaurant Admin Panel** - Complete dashboard with analytics  
✅ **Notification System** - Customizable sound alerts for new orders  
✅ **Sound Settings** - Different sounds for orders, payments, status updates  
✅ **Browser Notifications** - Desktop notifications with permission management  
✅ **Real-time Updates** - Live order tracking and status updates  
✅ **Sample Data** - One-click test data generation  

## Notification Sounds

The system includes 6 different notification sounds:
- **Bell** - Classic bell sound for orders
- **Chime** - Gentle chime for payments  
- **Ding** - Short ding for status updates
- **Beep** - Electronic beep
- **Notification** - Standard notification tone
- **Alert** - Urgent alert sound

Configure these in the Notifications page with:
- Volume control (0-100%)
- Ring count (1-5 rings)
- Enable/disable sounds
- Test each sound type

## Browser Requirements

Requires modern browser with support for:
- Web Audio API (for notification sounds)
- Notification API (for browser notifications)
- ES Modules

Tested on Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

## Troubleshooting

**No sounds playing?**
- Check browser permissions for notifications
- Ensure audio is not muted
- Try clicking the test buttons in notification settings

**Application not starting?**
- Make sure Node.js 18+ is installed
- Run `npm install` to install dependencies
- Check that port 5000 is available

**No data showing?**
- Click "Create Sample Data" in the dashboard
- Data is stored in-memory and resets on server restart

Enjoy your new restaurant admin panel with sound notifications!
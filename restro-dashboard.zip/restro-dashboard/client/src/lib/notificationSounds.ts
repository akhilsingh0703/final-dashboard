// Notification sound system for the admin panel
export interface NotificationSoundSettings {
  enabled: boolean;
  soundEnabled: boolean;
  volume: number;
  orderSound: string;
  paymentSound: string;
  statusSound: string;
  ringCount: number;
}

export const SOUND_OPTIONS = [
  { value: "bell", label: "Bell", frequency: 800 },
  { value: "chime", label: "Chime", frequency: 523 },
  { value: "ding", label: "Ding", frequency: 1000 },
  { value: "beep", label: "Beep", frequency: 440 },
  { value: "notification", label: "Notification", frequency: 659 },
  { value: "alert", label: "Alert", frequency: 880 },
];

export class NotificationSoundManager {
  private static audioContext: AudioContext | null = null;
  
  private static getAudioContext(): AudioContext {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return this.audioContext;
  }

  static getSettings(): NotificationSoundSettings {
    const saved = localStorage.getItem("notificationSettings");
    if (saved) {
      return JSON.parse(saved);
    }
    
    // Default settings
    return {
      enabled: true,
      soundEnabled: true,
      volume: 70,
      orderSound: "bell",
      paymentSound: "chime",
      statusSound: "ding",
      ringCount: 3,
    };
  }

  static playNotificationSound(type: 'order' | 'payment' | 'status' | string) {
    const settings = this.getSettings();
    
    if (!settings.enabled || !settings.soundEnabled) {
      return;
    }

    let soundType: string;
    switch (type) {
      case 'order':
        soundType = settings.orderSound;
        break;
      case 'payment':
        soundType = settings.paymentSound;
        break;
      case 'status':
        soundType = settings.statusSound;
        break;
      default:
        soundType = settings.orderSound; // Default to order sound
    }

    const sound = SOUND_OPTIONS.find(s => s.value === soundType);
    if (!sound) return;

    try {
      const audioContext = this.getAudioContext();
      
      // Resume audio context if it's suspended (required by some browsers)
      if (audioContext.state === 'suspended') {
        audioContext.resume();
      }

      // Play multiple rings with delay
      for (let i = 0; i < settings.ringCount; i++) {
        setTimeout(() => {
          this.playTone(audioContext, sound.frequency, settings.volume / 100);
        }, i * 600); // 600ms delay between rings
      }
    } catch (error) {
      console.warn('Could not play notification sound:', error);
    }
  }

  private static playTone(audioContext: AudioContext, frequency: number, volume: number) {
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
    oscillator.type = 'sine';
    
    // Create envelope for smooth sound
    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(volume * 0.3, audioContext.currentTime + 0.05);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.4);
  }

  static showBrowserNotification(title: string, message: string, type: string) {
    const settings = this.getSettings();
    
    if (!settings.enabled) {
      return;
    }

    // Request permission if not already granted
    if (Notification.permission === 'default') {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          this.createNotification(title, message, type);
        }
      });
    } else if (Notification.permission === 'granted') {
      this.createNotification(title, message, type);
    }
  }

  private static createNotification(title: string, message: string, type: string) {
    const notification = new Notification(title, {
      body: message,
      icon: '/vite.svg', // Use the app icon
      tag: `snapmenu-${type}`, // Prevent duplicate notifications
      requireInteraction: false,
    });

    // Auto-close after 5 seconds
    setTimeout(() => {
      notification.close();
    }, 5000);

    // Play sound when showing browser notification
    this.playNotificationSound(type);
  }
}

// Initialize permission request on first load
if (typeof window !== 'undefined' && 'Notification' in window) {
  if (Notification.permission === 'default') {
    // Don't request immediately, wait for user interaction
    document.addEventListener('click', () => {
      if (Notification.permission === 'default') {
        Notification.requestPermission();
      }
    }, { once: true });
  }
}
import { QueryClientProvider } from "@tanstack/react-query";
import { Router, Route, Switch } from "wouter";
import { queryClient } from "@/lib/queryClient";
import Dashboard from "@/pages/Dashboard";
import Restaurants from "@/pages/Restaurants";
import Orders from "@/pages/Orders";
import Notifications from "@/pages/Notifications";
import Sidebar from "@/components/Sidebar";
import { Toaster } from "@/components/ui/toaster";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="flex">
          <Sidebar />
          <main className="flex-1 ml-64">
            <div className="p-8">
              <Router>
                <Switch>
                  <Route path="/" component={Dashboard} />
                  <Route path="/restaurants" component={Restaurants} />
                  <Route path="/orders" component={Orders} />
                  <Route path="/notifications" component={Notifications} />
                  <Route>
                    <div className="text-center py-16">
                      <h1 className="text-2xl font-bold text-gray-900 dark:text-white">404 - Page Not Found</h1>
                    </div>
                  </Route>
                </Switch>
              </Router>
            </div>
          </main>
        </div>
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;
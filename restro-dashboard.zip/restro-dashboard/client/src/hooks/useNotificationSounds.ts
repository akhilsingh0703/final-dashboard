import { useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { NotificationSoundManager } from '@/lib/notificationSounds';

interface Notification {
  id: number;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  relatedId?: number;
  createdAt: string;
}

export function useNotificationSounds() {
  const { toast } = useToast();
  const lastNotificationCount = useRef(0);
  const lastNotificationId = useRef(0);

  // Query notifications for sound alerts
  const { data: notifications } = useQuery({
    queryKey: ["/api/notifications"],
    refetchInterval: 5000, // Poll every 5 seconds
  });

  useEffect(() => {
    if (notifications && Array.isArray(notifications) && notifications.length > 0) {
      // Sort by creation date to get the most recent first
      const sortedNotifications = [...notifications].sort((a: Notification, b: Notification) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

      const mostRecentNotification = sortedNotifications[0];
      
      // Check if this is a truly new notification (not just a refetch)
      if (lastNotificationId.current > 0 && mostRecentNotification.id > lastNotificationId.current) {
        // Find all new notifications since last check
        const newNotifications = sortedNotifications.filter((n: Notification) => 
          n.id > lastNotificationId.current
        );

        newNotifications.forEach((notification: Notification) => {
          const notificationType = notification.type || 'order';
          
          // Play sound based on notification type
          NotificationSoundManager.playNotificationSound(notificationType);
          
          // Show browser notification
          NotificationSoundManager.showBrowserNotification(
            notification.title,
            notification.message,
            notificationType
          );
          
          // Show toast notification (only for unread notifications)
          if (!notification.isRead) {
            toast({
              title: notification.title,
              description: notification.message,
            });
          }
        });
      }
      
      // Update tracking variables
      if (mostRecentNotification) {
        lastNotificationId.current = Math.max(lastNotificationId.current, mostRecentNotification.id);
      }
      lastNotificationCount.current = notifications.length;
    }
  }, [notifications, toast]);

  return {
    notifications,
    unreadCount: notifications?.filter((n: Notification) => !n.isRead).length || 0
  };
}
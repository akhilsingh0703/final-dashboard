import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Bell, Volume2, VolumeX, Play } from "lucide-react";

interface NotificationSettings {
  enabled: boolean;
  soundEnabled: boolean;
  volume: number;
  orderSound: string;
  paymentSound: string;
  statusSound: string;
  ringCount: number;
}

const SOUND_OPTIONS = [
  { value: "bell", label: "Bell", frequency: 800 },
  { value: "chime", label: "Chime", frequency: 523 },
  { value: "ding", label: "Ding", frequency: 1000 },
  { value: "beep", label: "Beep", frequency: 440 },
  { value: "notification", label: "Notification", frequency: 659 },
  { value: "alert", label: "Alert", frequency: 880 },
];

export function NotificationSettings() {
  const [settings, setSettings] = useState<NotificationSettings>({
    enabled: true,
    soundEnabled: true,
    volume: 70,
    orderSound: "bell",
    paymentSound: "chime",
    statusSound: "ding",
    ringCount: 3,
  });

  // Load settings from localStorage on component mount
  useEffect(() => {
    const savedSettings = localStorage.getItem("notificationSettings");
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
  }, []);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("notificationSettings", JSON.stringify(settings));
    // Also store globally for other components to access
    (window as any).notificationSettings = settings;
  }, [settings]);

  const playTestSound = (soundType: string) => {
    if (!settings.soundEnabled) return;
    
    const sound = SOUND_OPTIONS.find(s => s.value === soundType);
    if (!sound) return;

    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    for (let i = 0; i < settings.ringCount; i++) {
      setTimeout(() => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(sound.frequency, audioContext.currentTime);
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(settings.volume / 100, audioContext.currentTime + 0.1);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
      }, i * 600); // 600ms delay between rings
    }
  };

  const updateSettings = (key: keyof NotificationSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notification Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Enable/Disable Notifications */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="notifications-enabled">Enable Notifications</Label>
            <p className="text-sm text-muted-foreground">
              Receive notifications for new orders and updates
            </p>
          </div>
          <Switch
            id="notifications-enabled"
            checked={settings.enabled}
            onCheckedChange={(checked) => updateSettings("enabled", checked)}
          />
        </div>

        {/* Sound Settings */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="sound-enabled">Enable Sound</Label>
            <p className="text-sm text-muted-foreground">
              Play sound alerts for notifications
            </p>
          </div>
          <Switch
            id="sound-enabled"
            checked={settings.soundEnabled}
            onCheckedChange={(checked) => updateSettings("soundEnabled", checked)}
            disabled={!settings.enabled}
          />
        </div>

        {/* Volume Control */}
        {settings.soundEnabled && settings.enabled && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <VolumeX className="h-4 w-4" />
              <Label>Volume: {settings.volume}%</Label>
              <Volume2 className="h-4 w-4" />
            </div>
            <Slider
              value={[settings.volume]}
              onValueChange={(value) => updateSettings("volume", value[0])}
              max={100}
              min={0}
              step={10}
              className="w-full"
            />
          </div>
        )}

        {/* Ring Count */}
        {settings.soundEnabled && settings.enabled && (
          <div className="space-y-2">
            <Label>Number of Rings: {settings.ringCount}</Label>
            <Slider
              value={[settings.ringCount]}
              onValueChange={(value) => updateSettings("ringCount", value[0])}
              max={5}
              min={1}
              step={1}
              className="w-full"
            />
          </div>
        )}

        {/* Sound Selection */}
        {settings.soundEnabled && settings.enabled && (
          <div className="space-y-4">
            <h4 className="font-medium">Sound Settings for Different Events</h4>
            
            {/* Order Sound */}
            <div className="flex items-center justify-between">
              <div>
                <Label>New Order Sound</Label>
                <p className="text-sm text-muted-foreground">
                  Sound when a new order is received
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Select
                  value={settings.orderSound}
                  onValueChange={(value) => updateSettings("orderSound", value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SOUND_OPTIONS.map((sound) => (
                      <SelectItem key={sound.value} value={sound.value}>
                        {sound.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => playTestSound(settings.orderSound)}
                >
                  <Play className="h-3 w-3" />
                </Button>
              </div>
            </div>

            {/* Payment Sound */}
            <div className="flex items-center justify-between">
              <div>
                <Label>Payment Update Sound</Label>
                <p className="text-sm text-muted-foreground">
                  Sound when payment status changes
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Select
                  value={settings.paymentSound}
                  onValueChange={(value) => updateSettings("paymentSound", value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SOUND_OPTIONS.map((sound) => (
                      <SelectItem key={sound.value} value={sound.value}>
                        {sound.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => playTestSound(settings.paymentSound)}
                >
                  <Play className="h-3 w-3" />
                </Button>
              </div>
            </div>

            {/* Status Sound */}
            <div className="flex items-center justify-between">
              <div>
                <Label>Status Update Sound</Label>
                <p className="text-sm text-muted-foreground">
                  Sound when order status changes
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Select
                  value={settings.statusSound}
                  onValueChange={(value) => updateSettings("statusSound", value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SOUND_OPTIONS.map((sound) => (
                      <SelectItem key={sound.value} value={sound.value}>
                        {sound.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => playTestSound(settings.statusSound)}
                >
                  <Play className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Status Indicator */}
        <div className="pt-4 border-t">
          <div className="flex items-center gap-2">
            <Badge variant={settings.enabled ? "default" : "secondary"}>
              {settings.enabled ? "Notifications Enabled" : "Notifications Disabled"}
            </Badge>
            {settings.enabled && settings.soundEnabled && (
              <Badge variant="outline">
                Sound Enabled ({settings.volume}% volume, {settings.ringCount} rings)
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
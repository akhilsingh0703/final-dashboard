# Snapmenu Restaurant Admin Panel

A full-stack restaurant administration panel built with React, Express, and in-memory storage. Features real-time notifications with customizable sound alerts for managing restaurants, orders, customers, and notifications.

## Features

- **Real-time Dashboard** - Overview of restaurants, orders, and revenue
- **Restaurant Management** - Add, edit, and monitor restaurant performance
- **Order Tracking** - Comprehensive order management with status updates
- **Customer Management** - Customer database and contact information
- **Advanced Notifications** - Customizable sound alerts for different event types
- **Sound Settings** - Configure volume, ring count, and notification sounds
- **Browser Notifications** - Desktop notifications with permission management
- **Analytics** - Business intelligence and reporting charts
- **Sample Data** - One-click sample data generation for testing

## Tech Stack

### Frontend
- React 18 with TypeScript
- Vite for development and building
- Tailwind CSS for styling
- Shadcn/ui components with Radix UI
- TanStack Query for server state management
- Wouter for client-side routing
- Recharts for data visualization

### Backend
- Express.js with TypeScript
- In-memory storage system
- WebSocket for real-time updates
- RESTful API endpoints
- Type-safe API contracts

### Development
- TypeScript for type safety
- ESLint and Prettier for code quality
- Hot Module Replacement (HMR)
- Replit environment optimized

## Installation

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Development Mode**
   ```bash
   npm run dev
   ```
   This starts the Express server on port 5000 serving both API and frontend.

3. **Build for Production**
   ```bash
   npm run build
   ```

4. **Start Production Server**
   ```bash
   npm start
   ```

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utility functions
│   └── index.html
├── server/                 # Backend Express application
│   ├── index.ts            # Main server file
│   ├── routes.ts           # API routes
│   └── storage.ts          # In-memory storage system
├── shared/                 # Shared TypeScript types
│   └── schema.ts           # Database schema definitions
└── package.json
```

## API Endpoints

### Analytics
- `GET /api/analytics/dashboard` - Dashboard statistics
- `GET /api/analytics/restaurants/:id` - Restaurant analytics

### Restaurants
- `GET /api/restaurants` - List all restaurants
- `POST /api/restaurants` - Create new restaurant
- `PUT /api/restaurants/:id` - Update restaurant
- `DELETE /api/restaurants/:id` - Delete restaurant

### Orders
- `GET /api/orders` - List all orders
- `POST /api/orders` - Create new order
- `PUT /api/orders/:id` - Update order
- `PUT /api/orders/:id/status` - Update order status

### Customers
- `GET /api/customers` - List all customers
- `POST /api/customers` - Create new customer

### Notifications
- `GET /api/notifications` - List notifications
- `PUT /api/notifications/:id/read` - Mark as read

### Test Data
- `POST /api/test/create-sample-data` - Generate sample data

## Notification System

The application includes an advanced notification system with:

### Sound Settings
- **Different Sounds**: Bell, Chime, Ding, Beep, Notification, Alert
- **Volume Control**: 0-100% adjustable volume
- **Ring Count**: 1-5 rings per notification
- **Event Types**: Separate sounds for orders, payments, and status updates

### Configuration
Access notification settings in the Notifications page to:
- Enable/disable notifications
- Configure sound preferences
- Set volume levels
- Choose ring count
- Test different sound types

### Browser Notifications
- Desktop notification support
- Permission management
- Auto-close after 5 seconds
- Grouped by notification type

## Data Storage

The application uses **in-memory storage** which means:
- Data resets when server restarts
- No database setup required
- Perfect for development and testing
- Use "Create Sample Data" to populate test data

## Development Tips

1. **Sample Data**: Use the "Create Sample Data" button in the dashboard to populate the system with test restaurants, customers, and orders.

2. **Real-time Updates**: The dashboard polls for new notifications every 5 seconds and plays sounds automatically.

3. **Sound Testing**: Use the notification settings page to test different sound types and configure your preferences.

4. **Browser Permissions**: The app will request notification permissions on first interaction.

## Environment Variables

No environment variables required for basic operation. The application runs entirely in-memory.

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

Requires modern browser support for:
- Web Audio API (for notification sounds)
- Notification API (for browser notifications)
- ES Modules
- CSS Grid and Flexbox

## License

MIT License - Feel free to use this project for your own restaurant management needs.

---

Built with ❤️ for restaurant owners and administrators.
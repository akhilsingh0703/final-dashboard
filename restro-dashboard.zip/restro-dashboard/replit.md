# Restaurant Admin Panel - Replit Guide

## Overview

This is a full-stack restaurant administration panel built with React, Express, and in-memory storage. The application provides real-time management of restaurants, orders, customers, and notifications for a food delivery platform called "Snapmenu". Successfully migrated from PostgreSQL to frontend-only architecture with in-memory storage as requested.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite with custom configuration
- **Charts**: Recharts for data visualization

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Build Tool**: esbuild for production builds
- **Development**: tsx for TypeScript execution

### Storage Architecture
- **Storage**: In-memory storage system using TypeScript interfaces
- **Data Persistence**: Session-based storage (data resets on server restart)
- **Schema**: Defined in shared TypeScript files with full CRUD operations
- **Interface**: Abstract IStorage interface for consistent data operations
- **Initialization**: Automatic sample data creation functionality available

## Key Components

### Database Schema
The application manages four main entities:
- **Users**: Admin authentication (basic username/password)
- **Restaurants**: Restaurant information, status, and performance metrics
- **Customers**: Customer contact information and addresses
- **Orders**: Complete order details with items, pricing, and status tracking
- **Notifications**: Real-time system notifications

### API Structure
RESTful API endpoints organized by resource:
- `/api/restaurants` - Restaurant CRUD operations
- `/api/orders` - Order management and status updates
- `/api/customers` - Customer information
- `/api/notifications` - Notification system
- `/api/analytics` - Business intelligence and reporting

### Frontend Pages
- **Dashboard**: Overview with stats cards and charts
- **Restaurants**: Restaurant listing and management
- **Orders**: Order tracking and status management
- **Notifications**: Real-time notification center

### Real-time Features
- Automatic notification polling every 5 seconds
- Live order status updates
- Toast notifications for new events
- Real-time stats dashboard

## Data Flow

1. **Client Requests**: React components use TanStack Query for data fetching
2. **API Layer**: Express routes handle HTTP requests and validation
3. **Storage Layer**: Abstract storage interface (IStorage) defines data operations
4. **Database**: Drizzle ORM manages PostgreSQL interactions
5. **Response**: JSON responses with proper error handling

## External Dependencies

### UI and Styling
- Radix UI for accessible component primitives
- Tailwind CSS for utility-first styling
- Lucide React for consistent iconography
- Class Variance Authority for component variants

### Data and Forms
- TanStack Query for server state management
- React Hook Form with Zod validation
- Drizzle ORM for type-safe database operations

### Development Tools
- Vite for fast development and building
- TypeScript for type safety
- ESLint and Prettier for code quality
- Replit-specific development plugins

## Deployment Strategy

### Development
- Vite dev server with HMR for frontend
- tsx for TypeScript execution in development
- Automatic database schema synchronization

### Production
- Frontend built to `dist/public` directory
- Backend bundled with esbuild to `dist/index.js`
- Static file serving from Express in production
- Environment-based configuration

### Storage
- In-memory storage implementation in `server/storage.ts`
- Schema definitions in `shared/schema.ts` for type safety
- No persistent storage (data resets on server restart)
- Sample data generation available for testing

### Key Features
- Real-time notifications and updates with multiple notification types
- Advanced notification sound system with customizable audio alerts
- Different sound alerts for orders, payments, and status updates
- Configurable notification settings (volume, ring count, sound types)
- Browser notifications with permission management
- Responsive design with mobile support  
- Type-safe API contracts between frontend and backend
- Comprehensive order and restaurant management
- Analytics dashboard with charts and metrics
- Advanced restaurant analytics with daily/weekly/monthly order tracking
- Automatic notification system for order events, payment changes, and status updates
- Restaurant performance tracking including revenue, due payments, and rejection rates
- Sample data creation functionality for demonstration purposes
- Frontend-only architecture with in-memory storage (migrated from PostgreSQL)